import { Component } from '@angular/core';

@Component({
  selector: 'app-verifydocument',
  templateUrl: './verifydocument.component.html',
  styleUrls: ['./verifydocument.component.css']
})
export class VerifydocumentComponent {

}
