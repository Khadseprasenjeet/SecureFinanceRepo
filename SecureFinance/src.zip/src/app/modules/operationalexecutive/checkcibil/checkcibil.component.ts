import { Component } from '@angular/core';

@Component({
  selector: 'app-checkcibil',
  templateUrl: './checkcibil.component.html',
  styleUrls: ['./checkcibil.component.css']
})
export class CheckcibilComponent {

}
