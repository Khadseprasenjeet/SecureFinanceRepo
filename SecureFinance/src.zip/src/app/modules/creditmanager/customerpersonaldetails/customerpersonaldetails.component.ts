import { Component } from '@angular/core';

@Component({
  selector: 'app-customerpersonaldetails',
  templateUrl: './customerpersonaldetails.component.html',
  styleUrls: ['./customerpersonaldetails.component.css']
})
export class CustomerpersonaldetailsComponent {

}
