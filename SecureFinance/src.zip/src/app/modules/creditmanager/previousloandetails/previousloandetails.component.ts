import { Component } from '@angular/core';

@Component({
  selector: 'app-previousloandetails',
  templateUrl: './previousloandetails.component.html',
  styleUrls: ['./previousloandetails.component.css']
})
export class PreviousloandetailsComponent {

}
