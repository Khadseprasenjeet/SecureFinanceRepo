import { Component } from '@angular/core';

@Component({
  selector: 'app-createenquiry',
  templateUrl: './createenquiry.component.html',
  styleUrls: ['./createenquiry.component.css']
})
export class CreateenquiryComponent {

}
