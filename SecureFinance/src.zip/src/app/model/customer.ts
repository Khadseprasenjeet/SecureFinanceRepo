export class Customer {
}
