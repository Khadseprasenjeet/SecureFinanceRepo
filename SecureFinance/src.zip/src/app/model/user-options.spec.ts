import { UserOptions } from './user-options';

describe('UserOptions', () => {
  it('should create an instance', () => {
    expect(new UserOptions()).toBeTruthy();
  });
});
